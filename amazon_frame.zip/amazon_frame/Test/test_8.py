from POM.signin_page import SignInPage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def test_sign_in(driver, base_url):
    # Open sign-in page and click sign-in
    page = SignInPage(driver)
    page.open_login(base_url)
    minitv_link = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.XPATH, "//a[contains(@href, '/minitv?ref_=nav_avod_desktop_topnav')]"))
    )
    minitv_link.click()

    # Wait for MiniTV page to load
    WebDriverWait(driver, 10).until(EC.url_contains("minitv"))

    # Locate and click the "Battleground" thumbnail
    thumbnail = WebDriverWait(driver, 20).until(
        EC.element_to_be_clickable((By.XPATH, "//div[1]//div[2]//ul[1]//li[7]//div[1]//a[1]//div[1]")))
    driver.execute_script("arguments[0].scrollIntoView({block: 'center', behavior: 'smooth'});", thumbnail)
    time.sleep(0.5)  # Brief pause for scroll
    thumbnail.click()

    # Click "Watch Now" button
    watch_now_button = WebDriverWait(driver, 10).until(
        EC.element_to_be_clickable((By.CSS_SELECTOR, "img[width='64']")))
    watch_now_button.click()

    # Wait to observe result
    time.sleep(3)


    driver.quit()