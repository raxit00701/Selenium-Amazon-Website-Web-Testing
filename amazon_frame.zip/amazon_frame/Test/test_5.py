from POM.search_box import AmazonSearchPage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time
import random
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from webdriver_manager.chrome import ChromeDriverManager

def test_basic_search_and_select_iphone(driver, base_url):
    # 1) Open Amazon & search
    page = AmazonSearchPage(driver).open(base_url).search("apple")
    assert page.results_count() > 0
    print("✅ Search working, results found:", page.results_count())

    wait = WebDriverWait(driver, 15)

    # Wait for product cards to load
    WebDriverWait(driver, 10).until(
        EC.presence_of_all_elements_located((By.XPATH, "//div[@data-component-type='s-search-result']"))
    )

    # Find all product cards
    product_cards = driver.find_elements(By.XPATH, "//div[@data-component-type='s-search-result']")
    print(f"Found {len(product_cards)} product cards.")

    # Check if product cards are found
    if not product_cards:
        print("No product cards found on the page.")
        return

    # Randomly select a product card
    selected_card = random.choice(product_cards)
    print("Randomly selected a product card.")

    # Scroll to the selected product card to ensure it's in view
    driver.execute_script("arguments[0].scrollIntoView(true);", selected_card)
    time.sleep(1)  # Small delay to ensure smooth scrolling

    # Find the "Add to cart" button within the selected product card
    add_to_cart_button = selected_card.find_element(By.XPATH, ".//button[text()='Add to cart']")

    # Click the "Add to cart" button
    add_to_cart_button.click()
    print("Clicked 'Add to cart' button.")

    # Wait a moment to observe the result (e.g., cart update)
    time.sleep(3)

    # Click the cart icon
    driver.find_element(By.XPATH, "//span[@id='nav-cart-count']").click()
    print("Clicked 'Cart Icon' button.")

    # Wait for the subtotal to appear
    subtotal_element = WebDriverWait(driver, 10).until(
        EC.presence_of_element_located((By.XPATH, "//span[contains(@class, 'sc-price')]"))
    )

    subtotal_text = subtotal_element.text
    print(f"Subtotal text found: {subtotal_text}")

    # Remove currency symbol and commas (assumes ₹ symbol and Indian formatting)
    subtotal_clean = subtotal_text.replace("₹", "").replace(",", "").strip()

    # Parse subtotal to float
    subtotal_value = float(subtotal_clean)
    print(f"Parsed subtotal value: ₹{subtotal_value}")

    # Validate subtotal is greater than 0
    if subtotal_value > 0:
        print("✅ Subtotal price is valid.")
    else:
        print("❌ Subtotal is zero or invalid.")