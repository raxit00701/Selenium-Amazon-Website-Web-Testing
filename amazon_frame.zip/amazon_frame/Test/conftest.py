# conftest.py
import os
import re
import time
import base64
import pytest
from selenium import webdriver

# --- Folders (next to this conftest) ---
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
SCREENSHOTS_DIR = os.path.join(BASE_DIR, "screenshots")
LOGS_DIR = os.path.join(BASE_DIR, "logger")
os.makedirs(SCREENSHOTS_DIR, exist_ok=True)
os.makedirs(LOGS_DIR, exist_ok=True)

pytest_html = None  # will be set in pytest_configure


def safe_filename(name: str) -> str:
    """Replace unsafe path chars so we can use nodeid in file names."""
    return re.sub(r'[\\/:*?"<>|]', "_", name)


@pytest.fixture
def driver():
    options = webdriver.ChromeOptions()
    # enable browser console logs
    options.set_capability("goog:loggingPrefs", {"browser": "ALL"})
    d = webdriver.Chrome(options=options)
    d.maximize_window()
    yield d
    d.quit()


@pytest.fixture
def base_url():
    return "https://www.amazon.in"


def _embed_image_as_html(path: str) -> str:
    """Return an <img> tag with base64 so it shows inline in self-contained html."""
    with open(path, "rb") as f:
        b64 = base64.b64encode(f.read()).decode("utf-8")
    return f'<img src="data:image/png;base64,{b64}" style="max-width:500px;height:auto" onclick="window.open(this.src)" />'


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    """On failure: save screenshot + logs, print paths, and attach to pytest-html."""
    outcome = yield
    report = outcome.get_result()

    if report.when != "call" or not report.failed:
        return

    drv = item.funcargs.get("driver")
    if not drv:
        return

    ts = time.strftime("%Y%m%d_%H%M%S")
    base = safe_filename(item.nodeid.replace("::", "__"))
    png_path = os.path.join(SCREENSHOTS_DIR, f"{base}_{ts}.png")
    log_path = os.path.join(LOGS_DIR, f"{base}_{ts}.log")

    # Screenshot
    try:
        drv.save_screenshot(png_path)
    except Exception:
        png_path = None

    # Browser console logs
    logs = []
    try:
        logs = drv.get_log("browser")
    except Exception:
        pass
    with open(log_path, "w", encoding="utf-8") as f:
        if logs:
            for e in logs:
                level = e.get("level", "")
                msg = e.get("message", "")
                f.write(f"{level} - {msg}\n")
        else:
            f.write("No browser logs captured.\n")

    # Print to terminal
    if png_path:
        print(f"\n🖼️ Screenshot saved: {png_path}")
    print(f"📂 Logs saved: {log_path}")

    # Attach to pytest-html
    if pytest_html:
        extra = getattr(report, "extra", [])
        if png_path:
            # Inline image so it’s visible even with --self-contained-html
            extra.append(pytest_html.extras.html(_embed_image_as_html(png_path)))
        # Add a link to the log file (will still be clickable from the report)
        extra.append(pytest_html.extras.url(f"file://{log_path}", name="Browser Logs"))
        report.extra = extra


def pytest_configure(config):
    # get pytest-html plugin object so we can use its extras
    global pytest_html
    pytest_html = config.pluginmanager.getplugin("html")
