from POM.signin_page import SignInPage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def test_sign_in(driver, base_url):
    # Open sign-in page and click sign-in
    page = SignInPage(driver)
    page.open_login(base_url)


    def update_pincode(driver, pincode):
        # Wait for and click pincode button
        pincode_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//a[@id='nav-global-location-popover-link']"))
        )
        pincode_button.click()
        print("Clicked pincode button")
        time.sleep(2)

        # Wait for and interact with pincode field
        pincode_field = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.XPATH, "//input[@id='GLUXZipUpdateInput']"))
        )
        pincode_field.clear()
        if pincode:  # Only send keys if pincode is not empty
            pincode_field.send_keys(pincode)
        print(f"Entered pincode: {pincode}")
        time.sleep(2)

        # Wait for and click apply button
        apply_button = WebDriverWait(driver, 10).until(
            EC.element_to_be_clickable((By.XPATH, "//input[@class='a-button-input' and @type='submit' and @aria-labelledby='GLUXZipUpdate-announce']"))
        )
        apply_button.click()
        print("Clicked apply button")
        time.sleep(3)

    # Step 1: Enter valid pincode (example: 400001)
    print("Step 1: Testing valid pincode")
    update_pincode(driver, "400001")
    driver.refresh()
    time.sleep(3)

    # Step 2: Enter invalid pincode (example: 123)
    print("Step 2: Testing invalid pincode")
    update_pincode(driver, "123")
    driver.refresh()
    time.sleep(3)