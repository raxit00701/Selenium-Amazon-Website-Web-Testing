from POM.signin_page import SignInPage
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def test_sign_in(driver, base_url):
    page = SignInPage(driver)
    page.open_login(base_url).click_sign_in()
    assert "signin" in driver.current_url.lower()

    def fill_initial_email(email):
        driver.find_element(By.XPATH, "//input[@id='ap_email_login']").clear()
        driver.find_element(By.XPATH, "//input[@id='ap_email_login']").send_keys(email)
        driver.find_element(By.CSS_SELECTOR, ".a-button-inner .a-button-input").click()
        time.sleep(2)

    def click_confirm_button():
        driver.find_element(By.CSS_SELECTOR, "#intention-submit-button .a-button-inner > .a-button-input").click()
        time.sleep(2)

    def fill_form(mobile="", full_name="", password=""):
        # Mobile
        driver.find_element(By.ID, "ap_phone_number").clear()
        driver.find_element(By.ID, "ap_phone_number").send_keys(mobile)

        # Name
        driver.find_element(By.XPATH, "//input[@id='ap_customer_name']").clear()
        driver.find_element(By.XPATH, "//input[@id='ap_customer_name']").send_keys(full_name)

        # Password
        driver.find_element(By.XPATH, "//input[@id='ap_password']").clear()
        driver.find_element(By.XPATH, "//input[@id='ap_password']").send_keys(password)

    def click_verify_and_reset():
        driver.find_element(By.XPATH, "//input[@id='continue']").click()
        time.sleep(2)
        # Go back and reload to simulate full reset
        driver.get("https://www.amazon.in/ap/signin")  # Directly load the login page
        time.sleep(2)

    # Test cases
    test_cases = [
        {"mobile": "1234567890", "full_name": "John Doe", "password": "StrongPass123"},  # Valid
        {"mobile": "", "full_name": "Jane Smith", "password": ""},  # Missing mobile & password
        {"mobile": "abc", "full_name": "@@123", "password": "123"},  # All invalid
        {"mobile": "", "full_name": "", "password": ""}  # All empty
    ]

    # Run test cases with full flow each time
    for idx, case in enumerate(test_cases):
        print(f"\n--- Running Test Case {idx + 1} ---")
        page.open_login(base_url).click_sign_in()
        fill_initial_email("7654320432")
        click_confirm_button()
        fill_form(mobile=case["mobile"], full_name=case["full_name"], password=case["password"])
        click_verify_and_reset()

    driver.quit()
