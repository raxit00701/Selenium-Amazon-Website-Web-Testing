# pages/amazon_search_page.py
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class AmazonSearchPage:
    SEARCH_INPUT  = (By.ID, "twotabsearchtextbox")
    SEARCH_BUTTON = (By.ID, "nav-search-submit-button")
    RESULT_ITEMS  = (By.CSS_SELECTOR, "div.s-main-slot div[data-component-type='s-search-result']")

    def __init__(self, driver, timeout=10):
        self.driver = driver
        self.wait = WebDriverWait(driver, timeout)

    def open(self, base_url: str):
        self.driver.get(base_url)
        self.wait.until(EC.presence_of_element_located(self.SEARCH_INPUT))
        return self

    def search(self, term: str):
        box = self.wait.until(EC.element_to_be_clickable(self.SEARCH_INPUT))
        box.clear()
        box.send_keys(term)
        self.wait.until(EC.element_to_be_clickable(self.SEARCH_BUTTON)).click()
        self.wait.until(EC.presence_of_all_elements_located(self.RESULT_ITEMS))
        return self

    def results_count(self):
        return len(self.driver.find_elements(*self.RESULT_ITEMS))
